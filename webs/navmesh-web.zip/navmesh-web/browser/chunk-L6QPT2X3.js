var e={production:!0,useHash:!0,api:{baseUrl:"/api",refreshTokenEnabled:!1,refreshTokenType:"auth-refresh"}};export{e as a};
